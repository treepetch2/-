
// =====================
// 🔔 ตัวแปรหลัก
// =====================
let alarmTime = null;
let alarmActive = false;
let micActive = false;

const alarmSound = document.getElementById("alarmSound");

const clock = document.getElementById("clock");
const setBtn = document.getElementById("setBtn");
const alarmInput = document.getElementById("alarmInput");
const info = document.getElementById("info");
const status = document.getElementById("status");
const speakBtn = document.getElementById("speakBtn");


// =====================
// 🎤 Speech API
// =====================
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

recognition.lang = "th-TH";
recognition.continuous = false;


// =====================
// 🔓 ขอ permission ไมค์ก่อน (สำคัญ)
// =====================
navigator.mediaDevices.getUserMedia({ audio: true })
  .then(stream => {
    stream.getTracks().forEach(t => t.stop());
    status.textContent = "✔ พร้อมใช้งาน";
  })
  .catch(() => {
    status.textContent = "❌ ไม่อนุญาตไมค์";
  });


// =====================
// 🕒 นาฬิกา + เช็คปลุก
// =====================
setInterval(() => {

  const now = new Date();

  const h = String(now.getHours()).padStart(2, "0");
  const m = String(now.getMinutes()).padStart(2, "0");
  const s = String(now.getSeconds()).padStart(2, "0");

  clock.textContent = `${h}:${m}:${s}`;

  if (alarmTime && `${h}:${m}` === alarmTime && !alarmActive) {
    startAlarm();
  }

}, 1000);


// =====================
// 🎯 ตั้งปลุก
// =====================
setBtn.onclick = () => {
  alarmTime = alarmInput.value;
  info.textContent = "ตั้งปลุกไว้ที่ " + alarmTime;
};


// =====================
// 🔔 เริ่มปลุก
// =====================
function startAlarm() {
  alarmActive = true;

  status.textContent = "🔔 กำลังปลุก!";

  alarmSound.loop = true;
  alarmSound.play().catch(()=>{});
}


// =====================
// 🔇 หยุดปลุก
// =====================
function stopAlarm() {
  alarmActive = false;

  alarmSound.pause();
  alarmSound.currentTime = 0;

  status.textContent = "✔ หยุดปลุกแล้ว";
}


// =====================
// 🎤 ปุ่มพูด
// =====================
speakBtn.onclick = () => {

  if (!alarmActive) return;

  alarmSound.pause();

  micActive = true;

  speakBtn.classList.remove("mic-off");
  speakBtn.classList.add("mic-on");
  speakBtn.textContent = "🎤 กำลังฟัง...";

  recognition.start();
};


// =====================
// 🎧 ได้ผลเสียงจริง
// =====================
recognition.onresult = (event) => {

  const text = event.results[0][0].transcript;
  status.textContent = "พูดว่า: " + text;

  checkSpeech(text);
};


// =====================
// ❌ error
// =====================
recognition.onerror = () => {
  status.textContent = "ฟังไม่ชัด ลองใหม่";
  resetMic();
};


// =====================
// 🧠 ตรวจคำพูด
// =====================
function checkSpeech(text) {

  const now = new Date();

  const h = String(now.getHours()).padStart(2, "0");
  const m = String(now.getMinutes()).padStart(2, "0");

  const clean = text.replace(/\s/g, "");

  if (clean.includes(h) && clean.includes(m)) {

    status.textContent = "✔ ถูกต้อง!";
    stopAlarm();
    resetMic();

  } else {

    status.textContent = "❌ ผิด! เสียงจะกลับมา 3 วิ";

    resetMic();

    setTimeout(() => {
      if (alarmActive) {
        alarmSound.play();
      }
    }, 3000);
  }
}


// =====================
// 🔄 รีเซ็ตไมค์
// =====================
function resetMic() {
  micActive = false;

  speakBtn.classList.remove("mic-on");
  speakBtn.classList.add("mic-off");
  speakBtn.textContent = "🎤 กดเพื่อพูด";
}